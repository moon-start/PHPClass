<?php
    echo "你愛他 <br />";
    // echo '真的嗎？ <br />';
    print "他不愛你 <br />";
    /* 以下是猜的
    print '他有外遇 <br />';
    printf("你有外遇");
    */
?>